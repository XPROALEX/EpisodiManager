# Third-party notices

## StreamingCommunity catalog reference

The catalog parser retains compatibility with public page-data structures described in the **Blu-Tiger/StreamingCommunity-yt-dlp-plugin** project:
https://github.com/Blu-Tiger/StreamingCommunity-yt-dlp-plugin

That project is distributed under the MIT License (Copyright (c) 2024 BluTiger). Version 4.2.0 keeps the catalog/page-data compatibility only; the previous player-resolution and media-download path has been removed.

MIT License

Copyright (c) 2024 BluTiger

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

## yt-dlp

The application downloads the official Windows standalone executable from the yt-dlp release URL on first use and verifies its SHA-256 before execution. The executable is not bundled into the source archive or the main application EXE. See the official project for licensing and bundled third-party notices:
https://github.com/yt-dlp/yt-dlp

Pinned binary: yt-dlp 2026.10.26 (`yt-dlp.exe`).

The upstream release publishes the Windows standalone executable and SHA-256 checksums:
https://github.com/yt-dlp/yt-dlp/releases/tag/2026.10.26


## FFmpeg Windows builds

EpisodiManager 4.2.2 scarica al primo download l'archivio Windows x64 FFmpeg Essentials dal build provider Gyan (https://www.gyan.dev/ffmpeg/builds/), verifica l'hash SHA-256 dell'archivio e ne estrae soltanto `ffmpeg.exe` e `ffprobe.exe`. I binari non sono inclusi nel pacchetto EpisodiManager. La pagina del provider indica la licenza GPLv3 per i suoi build statici; consultare la pagina e i file di licenza inclusi nel pacchetto originale per i termini applicabili. FFmpeg è un progetto separato: https://ffmpeg.org/.
