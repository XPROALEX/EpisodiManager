# Episodi Manager 4.2.2

Applicazione Windows per organizzare serie ed episodi e gestire download da URL e sorgenti supportate da yt-dlp, da un'unica interfaccia locale.

## Novità 4.2.2

- Il downloader preferisce le migliori tracce video/audio separate (`bv+ba`) e le unisce con FFmpeg invece di scegliere sempre un unico flusso già combinato.
- Su Windows x64 FFmpeg e FFprobe vengono scaricati automaticamente al primo download, verificando SHA-256 dell'archivio, ed estratti nella cartella tools dell'app. Non occorre installare nulla manualmente.
- Dopo il download il file viene rimuxato senza ricodifica: MP4 con `-movflags +faststart` per creare un indice temporale e facilitare l'avanzamento/riavvolgimento. Se MP4 non è compatibile con i codec, viene tentato MKV senza perdita.
- FFprobe verifica la presenza della traccia video e una durata valida. Se l'ottimizzazione fallisce, il file originale viene conservato e l'app mostra un avviso.
- La stessa finalizzazione viene applicata anche ai download diretti di file video.

## Novità 4.2.1

- Nuova sezione **Download da sorgente supportata**, separata dal catalogo delle serie.
- Inserimento URL, analisi yt-dlp, titolo/estrattore/durata e qualità disponibili.
- Qualità selezionabile: migliore disponibile, fino a 1080p, 720p o 480p.
- Coda sequenziale con percentuale, velocità, ETA, file salvato, errori e pulsante di annullamento.
- Chiusura dell'ultima scheda del browser (o pulsante **Chiudi applicazione**) arresta il server e termina yt-dlp e i processi figli avviati dall'app. Un breve intervallo distingue la chiusura da un refresh.
- L'esportazione CSV non provoca più una navigazione che potrebbe far interpretare il download come chiusura dell'app.

## Supporto

- **AnimeUnity**: rilevamento tramite `info_api` a blocchi di 120 episodi; mantiene distinti numero visibile e ID interno.
- **StreamingCommunity (solo catalogo)**: lettura dei dati React Server Components di Next.js (`self.__next_f.push`), estrazione di stagioni/episodi e costruzione delle pagine di riproduzione. Il relativo download resta disattivato; il dominio viene bloccato anche nel downloader autonomo.
- **Downloader autonomo yt-dlp**: usa gli estrattori ufficiali inclusi in yt-dlp per URL video o pagine riconosciute, nei casi in cui si dispone dell'autorizzazione al download. Non aggira DRM, HTTP 403, login o altri controlli di accesso.

La compatibilità dipende dal sito e dagli estrattori presenti nella versione di yt-dlp; non tutti gli URL possono essere scaricati. La sezione analisi esegue `--dump-single-json` prima del download per controllare se il sito viene riconosciuto.

## Motore yt-dlp

- Su Windows x64 l'app scarica automaticamente `yt-dlp.exe` ufficiale al primo utilizzo, nella cartella `%APPDATA%\\EpisodiManager\\tools`.
- Il file viene verificato tramite SHA-256 prima di essere eseguito.
- Non serve installare Python, yt-dlp separatamente o usare il terminale.
- yt-dlp usa `bv+ba/b` (con limite di altezza se selezionato) e `--merge-output-format mkv` come contenitore intermedio, per massimizzare la compatibilità dei codec durante l’unione; la finalizzazione prova poi MP4 con fast-start e usa MKV come fallback.; FFmpeg è richiesto per unire tracce separate e per rimuxare il file finale.
- Su Windows x64 FFmpeg 9.0.2 Essentials viene scaricato dal build provider Gyan al primo download, l'archivio ZIP è verificato con SHA-256 e vengono estratti soltanto `ffmpeg.exe` e `ffprobe.exe`.
- Su Linux/macOS sono richiesti `ffmpeg` e `ffprobe` già presenti nel PATH.

Versioni fissate: yt-dlp **2026.10.26**; FFmpeg **9.0.2 Essentials**. La release ufficiale include un eseguibile Windows x64 standalone. Riferimenti: https://github.com/yt-dlp/yt-dlp/releases/tag/2026.10.26 e https://github.com/yt-dlp/yt-dlp. FFmpeg Windows build: https://www.gyan.dev/ffmpeg/builds/.

## Avvio su Windows

Estrai il pacchetto Windows e fai doppio clic su `EpisodiManager.exe`. Si apre l'interfaccia nel browser predefinito. Non servono Python, Go o .NET. Alla chiusura dell'ultima scheda dell'app viene chiuso anche il processo locale e vengono terminati i processi figli del downloader.

## Sviluppo

Requisiti: Go 1.23 o successivo.

```bash
go test ./...
go test -race ./...
go vet ./...
go run .
```

Per compilare Windows x64 da Windows, esegui `build_windows.bat`. Da shell con Go:

```bash
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-s -w -H=windowsgui" -o EpisodiManager.exe .
```

## File principali

- `main.go`: server locale, interfaccia, API, parser AnimeUnity/StreamingCommunity, ciclo di vita dell'app e motore yt-dlp.
- `process_windows.go` / `process_other.go`: gestione delle finestre console dei processi esterni.
- `main_test.go`: test unitari e simulati.
- `build_windows.bat`: script di compilazione Windows.
- `ARCHITETTURA.md`: flusso applicativo e gestione processi.
- `CHANGELOG.md`: cronologia delle modifiche.
- `THIRD_PARTY_NOTICES.md`: attribuzioni e informazioni sulle componenti esterne.

La libreria è salvata nel profilo utente in `EpisodiManager/library.json`.

## Uso responsabile

Usa l'applicazione solo per contenuti che hai il diritto o l'autorizzazione di acquisire e nel rispetto delle regole applicabili. yt-dlp viene usato tramite gli estrattori ufficiali per sorgenti autorizzate; Episodi Manager non tenta di superare DRM, paywall, HTTP 403 o altri controlli di accesso.
